import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifica-usuario',
  templateUrl: './modifica-usuario.component.html',
  styleUrls: ['./modifica-usuario.component.css']
})
export class ModificaUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
