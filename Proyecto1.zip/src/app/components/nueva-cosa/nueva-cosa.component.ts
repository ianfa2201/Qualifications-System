import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nueva-cosa',
  templateUrl: './nueva-cosa.component.html',
  styleUrls: ['./nueva-cosa.component.css']
})
export class NuevaCosaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
