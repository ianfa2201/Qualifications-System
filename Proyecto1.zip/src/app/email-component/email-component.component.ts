import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-component',
  templateUrl: './email-component.component.html',
  styleUrls: ['./email-component.component.css']
})
export class EmailComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
