import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-uppage',
  templateUrl: './sign-uppage.component.html',
  styleUrls: ['./sign-uppage.component.css']
})
export class SignUppageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
